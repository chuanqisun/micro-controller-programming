1. create a .env file based on the example in .env.example.
2. fill in your OpenAI API key in the .env file.
3. install node.js v24+
4. run `npm install` to install dependencies.
5. run `npm run serve` to start the server.
